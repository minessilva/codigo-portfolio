## KLAUZ DOING STUFF

NOT DONE YET

* POST: aumentar a linha svg para esta ficar até ao fim da página para depois por fazer a animação com o scroll (-scroll animation - http://www.w3schools.com/howto/howto_js_scrolldrawing.asp)

* loading page - https://ihatetomatoes.net/create-custom-preloading-screen/

DONE
* ~~o menu está aberto sempre que faço refresh~~
* ~~ABOVE THE FOLD ( C/ VIDEO )~~
* ~~o link do menu que vai para o WORKSPACE corresponde à segunda parte da página home (desenho com linha que está depois da seta)~~  
* ~~o menu está a desformatar na página home, não sei porquê, ficou sem o traço do meio do hamburger e items fora da caixa~~
* ~~a página do workspace dá acesso à segunda metade da homepage~~
* ~~inserir os metadados para a pesquisa (palavras-chave: ex - design, communication, graphic), basta fazer um e eu depois replico com outras palavras-chave (?)~~
* ~~MENU: dizer ao menu que quando passa pelo vídeo fica o logo a preto e o hamburger a vermelho (background-color: #f04319;)~~
* ~~WORKSPACE: colocar a imagem preenchida por baixo do desenho do contorno, a imagem preenchida tem de acompanhar a imagem do contorno encaixar sempre com ele~~
* ~~WORKSPACE: os subtítulos das secções (digital, editorial, etc) não devem ficar sobrepostos com o desenho do contorno~~
* ~~WORKSPACE: os hovers desaparecem - no caso da imagem com contorno da homepage o preenchimento aparece logo em vez de aparecer só no hover~~
* ~~ABOUT: em mobile tudo o que está em duas colunas para uma ( o que está na direita, vem para baixo)~~
* ~~ABOUT: export img for ABOUT~~
* ~~EDITORIAL: make for + style~~
* ~~POST: MOBILE: fica tudo numa coluna, o texto e o sub-titulo ficam mas a imagem em miniatura desaparece (ver imagem que está na pasta - mobile-disposicao/)~~
* ~~POST: panoramica e vídeos no topo - http://terrymun.github.io/paver/demo/index.html (isto só acontece nas outras páginas que vão ser replicadas por mim a partir desta)~~

***

OBSERVAÇÕES
* Homepage
 * o vídeo da homepage vai depois ser substituído por um que estou a fazer
